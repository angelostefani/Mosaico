# System Architecture — Mosaico RAG Platform

## 1. High-Level System Diagram

```mermaid
flowchart TD
    Browser["Browser\n(port 9001)"]
    Django["Django Frontend\nmosaico/ — port 9001\nBootstrap + JWT"]
    FastAPI["FastAPI AI API\nai_api/app.py — port 9000\n~2,887 lines"]
    Qdrant["Qdrant Vector DB\nport 6333\nHNSW + cosine"]
    Ollama["Ollama LLM\nport 11434\nlocal or remote"]
    PostgreSQL["PostgreSQL 16\nport 5432\nconversations, uploads, configs"]

    Browser -- "HTTPS (JWT cookie)" --> Django
    Django -- "Bearer JWT + form POST" --> FastAPI
    FastAPI -- "gRPC/REST" --> Qdrant
    FastAPI -- "HTTP streaming" --> Ollama
    FastAPI -- "SQLAlchemy ORM" --> PostgreSQL
    Django -- "SQLAlchemy / psycopg" --> PostgreSQL
```

**Deployment profiles** (from `docker-compose.yml`):
- **External Ollama** (`make up`): Ollama runs outside Docker; `OLLAMA_URL` points to remote host.
- **Local Ollama** (`make local`, `--profile local`): `ollama` and `ollama-pull` containers start; model is auto-pulled from `OLLAMA_MODEL` env var on first boot.

---

## 2. Component Breakdown

### 2.1 Ingestion Pipeline (`ai_api/app.py`)

| Function | Responsibility |
|---|---|
| `extract_text()` (line 915) | Dispatches to format-specific extractors |
| `_normalize_text()` (line 815) | Strips control chars, normalises whitespace |
| `chunk_text()` (line 828) | Sentence-aware sliding-window chunking |
| `_infer_page_number()` (line 894) | Maps byte offsets → page numbers for PDF/XLSX |
| `process_document()` (line 1101) | Orchestrates extract → chunk → embed → upsert |

Supported formats: `.txt`, `.md`, `.pdf` (pdfplumber), `.doc`/`.docx` (python-docx), `.xls`/`.xlsx` (openpyxl), `.json`.

### 2.2 Indexing Layer (Qdrant)

- Client initialised in `init_qdrant_client()` (line 1041).
- Collections created on first upload with `VectorParams(size=384, distance=Distance.COSINE)`.
- Collection naming: `_build_collection_name()` (line 449) → `{username}_{collection}` or fallback to `documents`.
- Points upserted via `client.upload_points()`.
- Compat shim `_qdrant_search_points()` (line 1052) handles both old (`client.search`) and new (`client.query_points`) Qdrant-client API versions.

### 2.3 Retrieval Engine (`ai_api/app.py`)

The retrieval engine runs inside the `/chat`, `/chat/stream`, and `/evaluation` endpoints:

| Stage | Function(s) | Toggle |
|---|---|---|
| Multi-vector search | `_select_query_expansions()`, loop in `/chat` | `ENABLE_MULTI_VECTOR_SEARCH` |
| Score threshold filter | inline in `/chat` | `QDRANT_SCORE_THRESHOLD` |
| Adaptive fallback | inline in `/chat` | automatic |
| Hybrid reranking | `rerank_results()` (line 1978) | `ENABLE_RERANK` |
| Cross-encoder reranking | `rerank_results()` with `_CrossEncoderHolder` | `ENABLE_CROSS_ENCODER_RERANK` |
| MMR diversity selection | `mmr_select()` (line 1865), `apply_mmr()` (line 2014) | `ENABLE_MMR` |
| Deduplication | `_dedup_results()` (line 1837) | always on |
| Chunk stitching | `stitch_chunks()` (line 1903) | `ENABLE_STITCH` |

### 2.4 Generation Layer (Ollama)

- Non-streaming: `ask()` async function (line 1325) — accumulates full response before returning.
- Streaming: `ask_stream()` async generator (line 1417) — yields text chunks; consumed by `/chat/stream`.
- Prompt structure: system instructions → scope section → RAG context → conversation history → question.
- Anti-prompt-injection rules are hardcoded into both `ask()` and `ask_stream()` prompts (7 numbered rules).

### 2.5 Evaluation Module (`evaluation/`)

- **`evaluation/eval_batch.py`**: Calls the `/evaluation` endpoint for each question in a JSON dataset; outputs a CSV with `question, reference, response, retrieved_contexts, retrieved_sources`.
- **`evaluation/eval_ragas.py`**: Reads the CSV and computes RAGAS metrics (faithfulness, answer_relevancy, context_precision, context_recall, answer_correctness) using a local Ollama LLM as judge and HuggingFace embeddings.
- **`evaluation/datasets/eval_dataset.json`**: Example dataset of 201+ question/reference pairs (domain: Italian energy communities / RECON simulator).

### 2.6 Django Frontend (`mosaico/`)

- JWT tokens obtained from `/api/token/` (djangorestframework-simplejwt, 60-minute lifetime).
- All API calls forward the Bearer token to FastAPI.
- Static files served by WhiteNoise in production.
- Key views in `ui/views.py`: login, register, upload, chat (streaming SSE consumer), uploads list, collection config, public chat.

### 2.7 Persistence (`ai_api/db.py`)

Four SQLAlchemy models:

| Model | Table | Key fields |
|---|---|---|
| `Upload` | `uploads` | `upload_id`, `username`, `collection`, `num_chunks`, `num_points`, `status` |
| `Conversation` | `conversations` | `conversation_id`, `user_id`, `collection`, `title` |
| `ConversationMessage` | `conversation_messages` | `conversation_id`, `role`, `content` |
| `CollectionConfig` | `collection_configs` | `collection_name`, `scope_prompt` |

DB engine selected via `DB_ENGINE` env var: `sqlite` (dev) or `postgres` (production).

---

## 3. Step-by-Step Data Flow

### 3.1 Ingestion (Upload Time)

```
1. Browser POST /upload (multipart/form-data) → Django
2. Django forwards multipart + Bearer JWT → FastAPI POST /upload
3. FastAPI: save raw file to UPLOAD_DIR (UUID-named)
4. create_upload_record() → status = "processing"
5. process_document():
   a. extract_text() → raw text + page metadata
   b. _normalize_text() → strip control chars, collapse whitespace
   c. chunk_text() → sentence-aware sliding window
      - step = CHUNK_SIZE - CHUNK_OVERLAP
      - boundary search: look for '.', '!', '?', '\n' within ±boundary_tolerance
   d. model.encode(chunks) → 384-dim float32 vectors (all-MiniLM-L6-v2)
   e. init_qdrant_client() → create collection if not exists
   f. Build PointStruct list: vector + payload (text_chunk, chunk_index,
      char_start, char_end, page_number, source_file, upload_id, ...)
   g. client.upload_points() → Qdrant HNSW index
6. update_upload_record() → status = "completed", num_chunks, num_points
7. Return JSON: upload_id, collection_used, num_chunks
```

### 3.2 Query (Chat Time)

```
1. Browser POST /chat/stream → Django → FastAPI
2. JWT verification (django_verify_token dependency)
3. Query expansion: _select_query_expansions() → up to CHAT_EXPANSION_LIMIT terms
4. Embed query + expansion terms: model.encode([question, t1, t2, ...])
5. Primary search: _qdrant_search_points(q_emb, limit=CHAT_CANDIDATES)
6. Expansion searches: per-term _qdrant_search_points(ti_vec, limit=CHAT_EXPANSION_CANDIDATES)
7. _merge_results() → deduplicate by point ID, keep highest score
8. Score threshold filter: keep score >= QDRANT_SCORE_THRESHOLD
   - Adaptive fallback: if empty, retry at 75%, 50%, 0% of threshold
9. Pool: take top pool_k = max(CHAT_RESULT_LIMIT * 2, CHAT_RESULT_LIMIT)
10. rerank_results():
    - If ENABLE_CROSS_ENCODER_RERANK: cross-encoder predict → sigmoid → 50%/50%
    - Else: 0.60 * vector_score + 0.25 * SequenceMatcher + 0.15 * keyword_overlap
11. apply_mmr(): mmr_select() with lambda=MMR_LAMBDA
12. _dedup_results(): fingerprint + SequenceMatcher >= 0.97 threshold
13. stitch_chunks(): merge consecutive chunks (same source/page/chunk_index+1)
    → respect CHAT_CONTEXT_CHAR_BUDGET
14. Build prompt: system + scope + context + history + question
15. ask_stream() → HTTP POST Ollama /api/generate stream=True
16. Yield SSE: data: {"chunk": "..."} ... data: {"done": true, "conversation_id": "..."}
17. Persist messages to conversation_messages table
```

---

## 4. Design Decisions and Rationale

### 4.1 Monolithic FastAPI Application

All RAG logic lives in a single `ai_api/app.py` file (~2,887 lines). This was a deliberate choice for simplicity in a local deployment context: no inter-service communication overhead, easy to run with a single `uvicorn` process.

> **Trade-off**: Reduces operational complexity but limits independent scaling of retrieval vs. generation stages.

### 4.2 Multi-Tenant Isolation via Qdrant Collections

Each `(username, collection)` pair maps to a dedicated Qdrant collection (`{username}_{collection}`). This provides hard data isolation between tenants without row-level security complexity.

> **Env var**: `QDRANT_HOST=qdrant`, `QDRANT_PORT=6333`

### 4.3 Lazy Embedding Model Loading

`_EmbeddingModelHolder` (line 168) uses a thread lock for lazy initialization. The model is loaded at startup via `preload_embedding_model_on_startup()` (line 759) to avoid cold-start on first request.

> **Env var**: `EMBEDDING_MODEL=all-MiniLM-L6-v2` (default), `ALLOW_EMBEDDING_FALLBACK=false` (production)

### 4.4 Sentence-Aware Chunking vs. Fixed-Size Chunking

The `chunk_text()` function uses a sliding window but adjusts the right boundary by searching for sentence-ending punctuation (`.`, `!`, `?`, `\n`) within a tolerance window of `min(50, CHUNK_SIZE // 10)` characters. This avoids cutting in the middle of sentences.

> **Env vars**: `CHUNK_SIZE=600` (default in `.env`), `CHUNK_OVERLAP=120`

### 4.5 Feature Flag Architecture

All major retrieval stages can be toggled independently via env vars (`ENABLE_RERANK`, `ENABLE_MMR`, `ENABLE_STITCH`, `ENABLE_MULTI_VECTOR_SEARCH`, `ENABLE_CROSS_ENCODER_RERANK`). This supports ablation studies without code changes.

### 4.6 Streaming SSE for Generation

The `/chat/stream` endpoint uses FastAPI `StreamingResponse` with `media_type="text/event-stream"`. The Ollama API is called with `stream=True` and each line of the NDJSON response is relayed as `data: {"chunk": "..."}`. This reduces time-to-first-token perceived latency.

### 4.7 Anti-Prompt-Injection Hardening

Both `ask()` and `ask_stream()` embed seven explicit rules in Italian at the start of every prompt, including instructions to ignore jailbreak attempts and to respond only from the provided context. This is a production-grade safety measure for a public-facing RAG application.

---

## 5. Known Bottlenecks

### 5.1 CPU-Bound Embedding

`sentence-transformers/all-MiniLM-L6-v2` runs on CPU by default in the Docker container (no GPU passthrough configured). Encoding a batch of 80 candidates at query time adds ~50–200ms latency on a modern CPU. Embedding is offloaded to a threadpool via `run_in_threadpool()` to avoid blocking the asyncio event loop.

### 5.2 Single Qdrant Instance

The deployment uses a single `qdrant/qdrant:latest` container with local volume storage. There is no replication, sharding, or read replicas. At high query volumes this becomes a bottleneck. The `ulimits.nofile` setting (65535) in `docker-compose.yml` mitigates file descriptor exhaustion.

### 5.3 Ollama Throughput on CPU

When running Ollama without a GPU (no `--gpus all` in docker-compose), generation throughput is limited to ~10–30 tokens/second depending on model size. `OLLAMA_TIMEOUT=180` (seconds) is set to accommodate slow CPU inference.

### 5.4 Synchronous Reranking

`rerank_results()` is called synchronously within the async request handler (not offloaded to a threadpool). For large candidate pools (`CHAT_CANDIDATES=80`) with cross-encoder enabled, this can block the event loop for hundreds of milliseconds.

> ⚠️ ASSUMPTION: Cross-encoder inference time on CPU was not benchmarked in the codebase; the estimate above is based on typical `cross-encoder/ms-marco-MiniLM-L-6-v2` performance.
