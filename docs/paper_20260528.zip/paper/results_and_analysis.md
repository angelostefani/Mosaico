# Results and Analysis — Mosaico RAG Platform

## 1. Ablation Study Design

All ablation studies are grounded in the `ENABLE_*` feature flags and numerical hyperparameters in `ai_api/app.py`. Each experiment uses the `/evaluation` endpoint + `eval_batch.py` + `eval_ragas.py` pipeline. The baseline configuration is the full system as configured in the `.env` file.

**Baseline configuration**:
- `ENABLE_RERANK=true`, `ENABLE_MMR=true`, `ENABLE_STITCH=true`, `ENABLE_MULTI_VECTOR_SEARCH=true`
- `ENABLE_CROSS_ENCODER_RERANK=false`
- `CHUNK_SIZE=600`, `CHUNK_OVERLAP=120`, `QDRANT_SCORE_THRESHOLD=0.45`
- `CHAT_RESULT_LIMIT=7`, `CHAT_CANDIDATES=80`, `MMR_LAMBDA=0.80`

---

## 2. Results Tables

### Table 1 — RAG Pipeline Ablation (Feature Flags)

> 🔬 ABLATION CANDIDATE: Toggle each `ENABLE_*` flag independently and in combination.

Each row corresponds to a different configuration of the five main feature flags.

| Config | Multi-Vec | Rerank | MMR | Stitch | Faithfulness | Ans. Relevancy | Ctx. Precision | Ctx. Recall | Ans. Correctness |
|---|---|---|---|---|---|---|---|---|---|
| Full system (baseline) | ✓ | ✓ | ✓ | ✓ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| No multi-vector | ✗ | ✓ | ✓ | ✓ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| No reranking | ✓ | ✗ | ✓ | ✓ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| No MMR | ✓ | ✓ | ✗ | ✓ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| No stitching | ✓ | ✓ | ✓ | ✗ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Retrieval only (no rerank, no MMR, no stitch) | ✓ | ✗ | ✗ | ✗ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Minimal (no multi-vec, no rerank, no MMR, no stitch) | ✗ | ✗ | ✗ | ✗ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Cross-encoder reranker | ✓ | CE | ✓ | ✓ | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |

*CE = cross-encoder/ms-marco-MiniLM-L-6-v2 replacing hybrid reranker.*

**Expected analysis**: The contribution of each stage to retrieval quality. Reranking and MMR are hypothesised to improve context precision at the cost of context recall (fewer but better chunks). Stitching is hypothesised to improve faithfulness by restoring inter-chunk continuity.

---

### Table 2 — Chunking Strategy Comparison

> 🔬 ABLATION CANDIDATE: `CHUNK_SIZE` at fixed `CHUNK_OVERLAP=120`; and `CHUNK_OVERLAP` at fixed `CHUNK_SIZE=600`.

| CHUNK_SIZE | CHUNK_OVERLAP | Avg. chunks/doc | Faithfulness | Ans. Relevancy | Ctx. Precision | Ctx. Recall | Ans. Correctness |
|---|---|---|---|---|---|---|---|
| 200 | 40 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 400 | 80 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 600 (baseline) | 120 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 800 | 160 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 1000 | 200 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 600 | 0 (no overlap) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 600 | 300 (50%) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |

**Expected analysis**: Smaller chunks improve context precision (more targeted retrieval) but may reduce recall (relevant context split across multiple non-retrieved chunks). Larger overlap is hypothesised to improve continuity of retrieved context.

---

### Table 3 — Retrieval k Comparison

> 🔬 ABLATION CANDIDATE: `CHAT_RESULT_LIMIT` (final context chunks) and `CHAT_CANDIDATES` (Qdrant retrieval pool).

| CHAT_CANDIDATES | CHAT_RESULT_LIMIT | Avg. ctx chars | Faithfulness | Ans. Relevancy | Ctx. Precision | Ctx. Recall | Ans. Correctness | Latency (ms) |
|---|---|---|---|---|---|---|---|---|
| 20 | 3 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 40 | 5 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 80 (baseline) | 7 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 80 | 10 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 100 | 15 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |

**Expected analysis**: Increasing `CHAT_CANDIDATES` increases recall at the cost of reranking latency. `CHAT_RESULT_LIMIT` controls the final context size; too many chunks may introduce noise and reduce faithfulness; too few may miss relevant content.

> 🔬 ABLATION CANDIDATE: Latency vs. quality Pareto frontier as a function of `CHAT_CANDIDATES`.

---

### Table 4 — MMR Lambda Sweep

> 🔬 ABLATION CANDIDATE: `MMR_LAMBDA` from 0.0 (pure diversity) to 1.0 (pure relevance).

| MMR_LAMBDA | Faithfulness | Ans. Relevancy | Ctx. Precision | Ctx. Recall | Ans. Correctness | Ctx. Diversity Score |
|---|---|---|---|---|---|---|
| 0.0 (pure diversity) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 0.2 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 0.4 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 0.5 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 0.65 (code default) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 0.80 (.env value) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| 1.0 (pure relevance) | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |

*Ctx. Diversity Score: mean pairwise SequenceMatcher distance among selected chunks.*

**Expected analysis**: Higher lambda favours relevance (expected to improve context precision), while lower lambda favours diversity (expected to improve context recall for multi-aspect questions). The optimal lambda is domain- and question-type dependent.

> 📌 PAPER OPPORTUNITY: The discrepancy between the code default (`MMR_LAMBDA=0.65`) and the deployed value (`MMR_LAMBDA=0.80`) suggests the authors empirically found a more relevance-biased setting to perform better. Reporting the sweep provides quantitative justification.

---

### Table 5 — Reranking Strategy Comparison

> 🔬 ABLATION CANDIDATE: No reranking vs. hybrid vs. cross-encoder; individual component weights.

| Strategy | vec weight | fuzzy weight | kw weight | Faithfulness | Ans. Relevancy | Ctx. Precision | Ctx. Recall | Ans. Correctness | Latency delta |
|---|---|---|---|---|---|---|---|---|---|
| No reranking (vector score only) | 1.0 | 0 | 0 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | 0 ms |
| Keyword only | 0 | 0 | 1.0 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Fuzzy only | 0 | 1.0 | 0 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Hybrid (60/25/15, baseline) | 0.60 | 0.25 | 0.15 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Hybrid equal (33/33/33) | 0.33 | 0.33 | 0.33 | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Cross-encoder (50/50) | 0.50 | — | — | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |
| Cross-encoder (25/75) | 0.25 | — | — | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] | [RESULT] |

*Latency delta: additional ms per query vs. no reranking.*

**Expected analysis**: The cross-encoder is expected to yield the highest context precision at the cost of additional latency. The hybrid reranker's 60/25/15 weighting is an empirical choice without published justification; this table provides that justification.

> 📌 PAPER OPPORTUNITY: The hybrid reranker combines three signals with fixed weights. Learning these weights via a small supervised dataset is a natural extension and a publishable contribution.

---

## 3. Analysis Framework

### 3.1 Primary Metrics

Following the RAGAS framework, four primary metrics are used:

$$\text{Faithfulness} = \frac{\text{claims in answer supported by context}}{\text{total claims in answer}}$$

$$\text{Answer Relevancy} = \frac{1}{N} \sum_{i=1}^{N} \text{CosSim}(q, \hat{q}_i)$$

where $\hat{q}_i$ are $N$ synthetic questions generated from the answer.

$$\text{Context Precision} = \frac{1}{K} \sum_{k=1}^{K} \frac{\text{relevant retrieved chunks up to } k}{\text{retrieved chunks up to } k}$$

$$\text{Context Recall} = \frac{\text{reference claims supported by context}}{\text{total claims in reference}}$$

### 3.2 Secondary Metrics

- **Retrieval latency** (ms): time from query embedding to first context character
- **Generation latency** (ms): time-to-first-token (relevant for streaming evaluation)
- **Context utilisation ratio**: `len(context) / CHAT_CONTEXT_CHAR_BUDGET` — how much of the budget is used
- **Average chunks retrieved**: mean `n_chunks` from `eval_batch.py` output
- **NaN rate**: fraction of RAGAS evaluations where judge LLM fails to return valid JSON

### 3.3 Claims Supported by Architecture

The following qualitative claims can be tested experimentally:

1. **Sentence-aware chunking** preserves more semantic units per chunk than fixed-size chunking → higher context precision.
2. **Multi-vector search** with query expansion improves recall for questions with synonymous or multi-faceted information needs.
3. **Hybrid reranking** corrects for false positives from dense retrieval where semantically similar but topically distant chunks receive high vector scores.
4. **MMR selection** reduces redundancy in the assembled context, particularly for large `CHAT_CANDIDATES` pools.
5. **Chunk stitching** improves faithfulness for questions requiring multi-sentence answers that span chunk boundaries.
6. **Adaptive score threshold fallback** prevents empty-context failures in sparse collections without degrading precision on dense collections.

### 3.4 Expected Failure Modes

| Scenario | Expected behaviour | Verifiable? |
|---|---|---|
| Query about content not in any indexed document | Returns "Nessun contesto rilevante." | Yes (negative test) |
| Very long document (>20MB) | HTTP 413 (enforced by `MAX_UPLOAD_SIZE_BYTES`) | Yes |
| Query with Italian stopwords only | Expansion returns empty; single vector search | Yes |
| Duplicate document upload | Both versions present in Qdrant; deduplication at retrieval | Yes |
| Prompt injection attempt | Hardcoded rules in prompt; response signals attempt | Qualitative |
| Ollama timeout | HTTP 503 with timeout detail | Yes |

---

## 4. Suggested Ablation Studies (Priority Order)

### Study A — Component Contribution (Table 1)
**Research question**: Which retrieval stages contribute most to end-to-end quality?
**Method**: Systematically disable each `ENABLE_*` flag, keeping others at baseline.
**Key metric**: Context Precision (primary), Faithfulness (secondary).
**Effort**: 7 configurations × 201 questions × ~3 minutes/question ≈ 3 days compute (with `gemma3:1b`).

### Study B — Chunk Size Optimisation (Table 2)
**Research question**: What is the optimal CHUNK_SIZE for Italian technical documents?
**Method**: Vary CHUNK_SIZE ∈ {200, 400, 600, 800, 1000} with proportional CHUNK_OVERLAP.
**Key metric**: F1 of (Context Precision, Context Recall).
**Note**: Requires re-ingesting the full document collection for each configuration.

### Study C — MMR Lambda Sweep (Table 4)
**Research question**: Is the deployed MMR_LAMBDA=0.80 optimal?
**Method**: Grid search λ ∈ {0.0, 0.2, 0.4, 0.5, 0.65, 0.80, 1.0}.
**Key metric**: Weighted combination of Context Precision and Context Recall.
**Effort**: 7 configurations × 201 questions (no re-indexing required).

### Study D — Reranker Comparison (Table 5)
**Research question**: Does the cross-encoder improve quality enough to justify latency overhead?
**Method**: Compare no-rerank, hybrid, cross-encoder configurations.
**Key metric**: Context Precision vs. latency Pareto curve.

### Study E — Judge Model Reliability
**Research question**: How does judge LLM size affect RAGAS metric reliability?
**Method**: Run `eval_ragas.py` with multiple judge models (gemma3:1b, gemma3:4b, gemma4:26b).
**Key metric**: NaN rate, score variance, score correlation across models.
**Motivation**: Documented limitation in `eval_ragas.py` — "faithfulness scores are biased upward".

> 📌 PAPER OPPORTUNITY: Study E addresses a fundamental limitation of LLM-as-judge evaluation that is widely acknowledged but rarely empirically characterised with local models.
