# Glossary — Mosaico RAG Platform

## Format

Each entry provides: English term | Italian translation | Technical definition in Mosaico context | Literature reference | Contested flag where applicable.

---

### Answer Relevancy
**Italian**: Pertinenza della risposta

**Definition**: A RAGAS evaluation metric measuring how well the generated answer addresses the original question. Computed as the average cosine similarity between the original question and $N$ synthetic questions generated from the answer. In `eval_ragas.py`, the metric uses `AnswerRelevancy(llm=llm, embeddings=embeddings, strictness=1)` where `strictness=1` means one synthetic question per sample (reduced from RAGAS default of 3 to avoid LLM queue overload with a local model).

**Reference**: Es, S., et al. (2023). RAGAS. arXiv:2309.15217.

---

### Bi-Encoder
**Italian**: Bi-codificatore (o doppio codificatore)

**Definition**: A neural architecture that encodes query and document independently into the same embedding space, enabling pre-computation of document embeddings. In Mosaico, `all-MiniLM-L6-v2` is the bi-encoder used both at ingestion (`model.encode(chunks)`) and at query time (`model.encode([question] + expansion_terms)`). Contrast with cross-encoder, which jointly encodes query and document.

**Reference**: Reimers, N., & Gurevych, I. (2019). Sentence-BERT. EMNLP 2019.

---

### Chunk
**Italian**: Frammento di testo (o chunk)

**Definition**: A contiguous substring of a normalised document, produced by `chunk_text()` in `app.py`. Each chunk has a maximum length of `CHUNK_SIZE` characters (default 600) and overlaps with adjacent chunks by `CHUNK_OVERLAP` characters (default 120). Chunks are the atomic unit of indexing, retrieval, and context assembly. Each chunk is stored as a single Qdrant point with its vector and payload.

**Reference**: Lewis, P., et al. (2020). RAG for Knowledge-Intensive NLP. NeurIPS 2020.

---

### Collection
**Italian**: Collezione (Qdrant)

**Definition**: A named namespace in Qdrant that groups vector points with the same dimensionality and distance metric. In Mosaico, each `(username, collection_name)` pair maps to a dedicated Qdrant collection named `{username}_{collection_name}` (via `_build_collection_name()`). Collections provide hard multi-tenant isolation: a query against one collection cannot access points in another. Collections are created automatically on first document upload.

**Reference**: Qdrant documentation — https://qdrant.tech/documentation/concepts/collections/

---

### Context Precision
**Italian**: Precisione del contesto

**Definition**: A RAGAS metric measuring the fraction of retrieved chunks that are relevant to the question. Formally, it is the mean precision at rank $k$ over all retrieved positions. In `eval_ragas.py`, computed by `ContextPrecision(llm=llm)` using an LLM judge. High context precision indicates the retrieval pipeline is not including irrelevant chunks in the assembled context.

**Reference**: Es, S., et al. (2023). RAGAS. arXiv:2309.15217.

---

### Context Recall
**Italian**: Richiamo del contesto

**Definition**: A RAGAS metric measuring the fraction of claims in the reference answer that are covered by the retrieved contexts. Requires a reference answer. Computed by `ContextRecall(llm=llm)`. High context recall indicates the retrieval pipeline found the evidence needed to answer the question. A system with high precision but low recall retrieves few but accurate chunks; increasing `CHAT_CANDIDATES` typically improves recall.

**Reference**: Es, S., et al. (2023). RAGAS. arXiv:2309.15217.

---

### Context Window
**Italian**: Finestra di contesto

**Definition**: The maximum number of tokens (or characters) that can be included in a single LLM prompt. In Mosaico, the context window is managed at the character level via `CHAT_CONTEXT_CHAR_BUDGET=9000` characters (approximately 2,000–2,500 tokens depending on language). The `stitch_chunks()` function enforces this budget by truncating the last stitched block at a sentence boundary.

> ⚠️ CONTESTED: Token budgets depend on the tokeniser of the specific Ollama model (e.g., Gemma uses a different tokeniser than LLaMA). Using character counts is a model-agnostic approximation.

---

### Cosine Similarity
**Italian**: Similarità coseno

**Definition**: The similarity measure used by Qdrant for vector search in Mosaico. Defined as:

$$\text{sim}(q, d) = \frac{q \cdot d}{\|q\| \cdot \|d\|}$$

where $q$ and $d$ are 384-dimensional float32 vectors produced by `all-MiniLM-L6-v2`. Values range from −1 to 1; Mosaico filters out results below `QDRANT_SCORE_THRESHOLD=0.45`. Qdrant returns scores already normalised to [0, 1] for cosine distance.

**Reference**: Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. *Information Processing & Management*.

---

### Cross-Encoder
**Italian**: Cross-codificatore (o reranker cross-attention)

**Definition**: A neural model that jointly encodes a query-document pair through cross-attention, producing a single relevance score. In Mosaico, `cross-encoder/ms-marco-MiniLM-L-6-v2` is used when `ENABLE_CROSS_ENCODER_RERANK=true`. The raw logit is passed through a sigmoid function and combined 50/50 with the Qdrant vector score. Loaded lazily via `_CrossEncoderHolder`. More accurate than bi-encoders but $O(n)$ rather than $O(1)$ at query time (cannot pre-compute document representations).

**Reference**: Nogueira, R., & Cho, K. (2019). Passage Re-ranking with BERT. arXiv:1901.04085.

---

### Embedding
**Italian**: Vettore semantico (o embedding)

**Definition**: A dense, fixed-length numerical representation of text that encodes semantic meaning. In Mosaico, `all-MiniLM-L6-v2` produces 384-dimensional float32 embeddings. Computed at ingestion time for each chunk, and at query time for the question and expansion terms. Stored in Qdrant as the vector component of each point.

**Reference**: Reimers, N., & Gurevych, I. (2019). Sentence-BERT. EMNLP 2019.

---

### Faithfulness
**Italian**: Fedeltà al contesto

**Definition**: A RAGAS metric measuring the degree to which the generated answer is grounded in the retrieved context. Specifically, the fraction of factual claims in the answer that can be inferred from the retrieved chunks. Computed by `Faithfulness(llm=llm)` using an LLM judge. An unfaithful answer contains hallucinations — claims not supported by the retrieved context.

> ⚠️ CONTESTED: When the same model generates the answer and acts as judge (as in `eval_ragas.py` with a local Ollama model), faithfulness scores are systematically biased upward — the judge tends to validate claims it would also generate. The `eval_ragas.py` docstring explicitly documents this limitation.

**Reference**: Es, S., et al. (2023). RAGAS. arXiv:2309.15217.

---

### Fingerprinting
**Italian**: Impronta digitale (del chunk)

**Definition**: A lightweight deduplication technique used in `_dedup_results()` (line 1837). Each chunk is represented by a tuple `(len(normalised_text), normalised_text[:64], normalised_text[-64:])`. Exact fingerprint matches are detected in O(1) time via a hash set, avoiding expensive string comparison for identical chunks. Near-duplicates are then detected by `SequenceMatcher` on chunks sharing identical numeric token sequences.

---

### HNSW
**Italian**: HNSW (Hierarchical Navigable Small World)

**Definition**: A graph-based algorithm for approximate nearest-neighbour search in high-dimensional vector spaces. In Mosaico, Qdrant uses HNSW as its default index for vector collections. HNSW builds a hierarchical graph where each node connects to $m$ neighbours; search traverses the graph from a high-level entry point to increasingly fine-grained layers. Construction parameters (`m`, `ef_construct`) are not explicitly configured in Mosaico; Qdrant defaults are used.

> ⚠️ ASSUMPTION: Default Qdrant HNSW parameters are `m=16`, `ef_construct=100`, `ef=128` at search time. These are not set in `app.py` or `docker-compose.yml`.

**Reference**: Malkov, Y. A., & Yashunin, D. A. (2018). Efficient and robust approximate nearest neighbor search using Hierarchical Navigable Small World graphs. *IEEE T-PAMI*.

---

### MMR (Maximal Marginal Relevance)
**Italian**: Massima Rilevanza Marginale

**Definition**: A greedy selection algorithm that balances relevance and diversity:

$$d^* = \arg\max_{d_i \in \mathcal{R} \setminus S} \left[ \lambda \cdot s_\text{rel}(d_i) - (1-\lambda) \cdot \max_{d_j \in S} \text{sim}(d_i, d_j) \right]$$

In Mosaico (`mmr_select()`, line 1865), relevance scores come from the hybrid reranker, and similarity uses `SequenceMatcher` ratio on chunk text (not embedding cosine). The first item selected is always the highest-relevance candidate. `MMR_LAMBDA=0.80` in production (code default: 0.65).

**Reference**: Carbonell, J., & Goldstein, J. (1998). The Use of MMR, Diversity-Based Reranking. *SIGIR 1998*.

---

### Multi-Tenant
**Italian**: Multi-tenancy (o multi-utente isolato)

**Definition**: A deployment model where multiple independent users or organisations share the same infrastructure while maintaining strict data isolation. In Mosaico, tenancy is implemented at the Qdrant collection level: each `(username, collection)` pair gets a dedicated collection. This ensures that a user's queries only search their own documents. `_build_collection_name()` (line 449) enforces the naming convention `{username}_{collection}`.

---

### Query Expansion
**Italian**: Espansione della query

**Definition**: The technique of adding additional terms to a query to improve recall. In Mosaico (`_select_query_expansions()`, line 1774), expansion terms are extracted from the question itself (not from an external thesaurus or LLM). Tokens are ranked by frequency and position, stopwords are filtered, and the top `CHAT_EXPANSION_LIMIT=3` tokens become independent Qdrant queries. This is a form of *pseudo-relevance feedback* applied before any retrieval.

> 📌 PAPER OPPORTUNITY: The current expansion is purely extractive (from the question itself). LLM-based query expansion (generating reformulations of the question) is a stronger but costlier alternative.

**Reference**: Rocchio, J. J. (1971). Relevance Feedback in Information Retrieval. *The SMART Retrieval System*.

---

### RAG (Retrieval-Augmented Generation)
**Italian**: Generazione Aumentata dal Recupero di Informazioni

**Definition**: A paradigm in which a language model's responses are grounded by dynamically retrieved external knowledge. The retrieval step replaces or supplements the model's parametric memory with relevant text passages. In Mosaico, the pipeline is: embed query → search Qdrant → rerank → MMR → stitch → assemble prompt → call Ollama. The LLM is instructed to use *only* the retrieved context (rule 1 in the system prompt).

**Reference**: Lewis, P., et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.

---

### Reranking
**Italian**: Re-classificazione (o riordinamento dei risultati)

**Definition**: A post-retrieval step that rescores candidate documents using a richer model than the initial retrieval. In Mosaico (`rerank_results()`, line 1978), two rerankers are available: (a) **hybrid reranker** (default): combines vector score, SequenceMatcher ratio, and keyword overlap with 60/25/15 weights; (b) **cross-encoder** (optional): uses `cross-encoder/ms-marco-MiniLM-L-6-v2` with sigmoid normalisation, combined 50/50 with vector score.

**Reference**: Nogueira, R., & Cho, K. (2019). Passage Re-ranking with BERT. arXiv:1901.04085.

---

### Sentence-Aware Chunking
**Italian**: Segmentazione a consapevolezza di frase

**Definition**: A chunking strategy that adjusts chunk boundaries to coincide with sentence-ending punctuation marks rather than cutting at a fixed character offset. In Mosaico (`chunk_text()`, line 828), when a candidate chunk boundary falls within a text that continues, the algorithm searches backward up to `boundary_tolerance = min(50, CHUNK_SIZE ÷ 10)` characters for `.`, `!`, `?`, or `\n`. If found, the boundary is moved to that position. This is a heuristic that avoids mid-sentence truncation without requiring a full sentence tokeniser.

> ⚠️ CONTESTED: The boundary heuristic assumes sentences end with `.!?\n`. It degrades for languages or documents where sentence boundaries are marked differently (e.g., abbreviations followed by periods, Asian scripts without punctuation).

---

### SSE (Server-Sent Events)
**Italian**: Eventi inviati dal server

**Definition**: A unidirectional HTTP protocol where the server pushes a stream of messages to the client. In Mosaico, the `/chat/stream` endpoint uses SSE (via FastAPI `StreamingResponse` with `media_type="text/event-stream"`) to stream LLM-generated tokens to the browser as they arrive from Ollama. Each event is formatted as `data: {"chunk": "token_text"}\n\n`. The terminal event is `data: {"done": true, "conversation_id": "..."}\n\n`.

**Reference**: WHATWG. Server-Sent Events specification. https://html.spec.whatwg.org/multipage/server-sent-events.html

---

### Stitching
**Italian**: Ricucitura (dei frammenti)

**Definition**: A post-MMR step in Mosaico (`stitch_chunks()`, line 1903) that merges consecutive chunks from the same document page into single blocks. Two chunks are "consecutive" if they share the same `source_file`, `page_number`, and their `chunk_index` values differ by exactly 1. Runs are limited to `max_run_len=3` chunks. Stitching restores the local context that was fragmented during the chunking phase, particularly useful for answers requiring multi-sentence explanations.

> 📌 PAPER OPPORTUNITY: Stitching is functionally similar to the "parent-document retrieval" pattern in LangChain, but implemented without a hierarchical index. A comparison of the two approaches is a novel contribution.

---

### Top-K Retrieval
**Italian**: Recupero dei K migliori

**Definition**: Retrieving the $K$ most similar documents/chunks to a query from the vector index. In Mosaico, two values of $K$ are relevant: (1) `CHAT_CANDIDATES=80` — number of candidates retrieved from Qdrant before reranking; (2) `CHAT_RESULT_LIMIT=7` — number of chunks actually included in the assembled context after all post-processing stages. The ratio `CHAT_CANDIDATES / CHAT_RESULT_LIMIT` (≈ 11×) defines the reranking compression ratio.

---

### Vector Store
**Italian**: Archivio vettoriale (o indice vettoriale)

**Definition**: A database optimised for storing and querying high-dimensional embedding vectors using approximate nearest-neighbour algorithms. In Mosaico, Qdrant (`qdrant/qdrant:latest`) serves as the vector store. Each document chunk is stored as a Qdrant `PointStruct` containing a UUID, a 384-dimensional float32 vector, and a JSON payload with chunk metadata. Qdrant uses HNSW indexing with cosine distance.

**Reference**: Johnson, J., Douze, M., & Jégou, H. (2019). Billion-Scale Similarity Search with GPUs. *IEEE T-BD*.
