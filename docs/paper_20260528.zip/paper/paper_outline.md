# Paper Outline — Mosaico RAG Platform

## 1. Title Variants

**Variant A** (systems focus):
> "Mosaico: A Privacy-First Modular RAG Platform with Sentence-Aware Chunking, Hybrid Reranking, and MMR Diversity Selection"

**Variant B** (evaluation focus):
> "On-Premises Retrieval-Augmented Generation: Architecture, Ablation Study, and RAGAS Evaluation of a Local Document QA System"

**Variant C** (applied focus):
> "Mosaico: Design and Evaluation of a Fully Local Multi-Tenant RAG System for Italian Technical Document Q&A"

---

## 2. Abstract Template (~150 words)

> Retrieval-Augmented Generation (RAG) systems typically depend on cloud-hosted APIs, raising concerns about data privacy in sensitive domains. We present **Mosaico**, a modular, fully on-premises RAG platform for document question answering that operates with no cloud dependencies. Mosaico introduces [NUMBER] technical contributions: (1) a sentence-boundary-aware sliding-window chunker that avoids mid-sentence truncation without requiring an external tokeniser; (2) a lightweight hybrid reranker combining dense vector similarity, SequenceMatcher fuzzy matching, and keyword overlap; (3) a Maximal Marginal Relevance selector using lexical similarity for diversity estimation, avoiding a second embedding lookup; and (4) a consecutive-chunk stitching mechanism that restores inter-chunk context continuity. We evaluate Mosaico on a domain-specific Italian dataset of [NUMBER] question-answer pairs using the RAGAS framework with a local LLM judge. Ablation studies across [NUMBER] configurations show that [KEY_FINDING]. Our implementation is open source and deployable via Docker Compose on commodity hardware.

**Placeholder tokens**: [NUMBER], [KEY_FINDING]

---

## 3. Full Section Outline

### Section 1 — Introduction

- **Motivation**: Enterprise and public-sector organisations handle sensitive documents that cannot leave the organisation's perimeter; cloud RAG APIs (OpenAI, Cohere, etc.) are therefore unusable for compliance, GDPR, or sovereignty reasons.
- **Gap**: Most published RAG systems assume cloud embedding and generation APIs. Local RAG deployments are underexplored in the literature, particularly for non-English (Italian) technical documents.
- **Contribution statement**: We present Mosaico, a fully local RAG stack with five independently toggleable retrieval enhancement stages, evaluated with RAGAS on a domain-specific Italian dataset.
- **Paper structure**: Brief roadmap of remaining sections.
- **Reproducibility**: All code and dataset available at [GitHub URL]; all experiments reproducible via Docker Compose.

### Section 2 — Background

- **RAG fundamentals**: Lewis et al. (2020) NeurIPS formulation; standard pipeline (index, retrieve, generate); limitations of purely parametric LLMs for knowledge-intensive tasks.
- **Sentence transformers**: Reimers & Gurevych (2019) SBERT; `all-MiniLM-L6-v2` as a distilled bi-encoder balancing quality and CPU performance.
- **Vector databases**: HNSW index properties (approximate nearest-neighbour, logarithmic search); Qdrant as an open-source vector DB with REST and gRPC interfaces.
- **Evaluation**: RAGAS framework (Es et al., 2023); five metrics; LLM-as-judge paradigm and its limitations.
- **Local LLM deployment**: Ollama as a unified inference server; quantisation tradeoffs; `gemma4:26b` and `gemma3:1b` as example models.

### Section 3 — System Architecture

- **Component overview**: Browser → Django (JWT auth, Bootstrap UI) → FastAPI (RAG logic) → Qdrant (vector index) + Ollama (LLM) + PostgreSQL (persistence).
- **Multi-tenant design**: `_build_collection_name()` mapping `(username, collection)` → dedicated Qdrant collection; isolation guarantees vs. filter-based multi-tenancy.
- **Deployment modes**: External Ollama (`make up`) vs. local Ollama (`make local`, `--profile local` with `ollama-pull` auto-download).
- **Data models** (`ai_api/db.py`): `Upload`, `Conversation`, `ConversationMessage`, `CollectionConfig`; dual-engine support (SQLite dev, PostgreSQL production).
- **Security**: JWT token forwarding from Django to FastAPI; `SKIP_AUTH` for development; anti-prompt-injection system prompt rules.

### Section 4 — Methodology

#### 4.1 Ingestion Pipeline
- Supported formats: `.txt`, `.md`, `.pdf` (pdfplumber), `.docx` (python-docx), `.xls`/`.xlsx` (openpyxl), `.json`.
- `_normalize_text()`: control character removal, whitespace collapse, CRLF normalisation.
- `chunk_text()`: sentence-boundary heuristic algorithm; default `CHUNK_SIZE=600`, `CHUNK_OVERLAP=120`; `boundary_tolerance=min(50, CHUNK_SIZE÷10)`.
- Chunk payload schema: `text_chunk`, `chunk_index`, `char_start`, `char_end`, `page_number`, `source_file`, `upload_id`.

#### 4.2 Embedding and Indexing
- `sentence-transformers/all-MiniLM-L6-v2`; 384 dimensions; cosine similarity; lazy-loaded with thread-safe double-checked locking.
- Qdrant HNSW collection creation; `VectorParams(size=384, distance=Distance.COSINE)`.

#### 4.3 Retrieval Pipeline (5 stages)
- **Stage 1**: Multi-vector search; stopword-filtered token expansion; parallel Qdrant queries; score-based merge.
- **Stage 2**: Cosine score threshold filtering with adaptive fallback (0.75×, 0.5×, 0.0 progressive relaxation).
- **Stage 3**: Hybrid reranking: $0.60 s_\text{vec} + 0.25 \text{SequenceMatcher} + 0.15 \text{KeywordOverlap}$; optional cross-encoder 50/50.
- **Stage 4**: MMR: $\lambda s_\text{rel}(d) - (1-\lambda)\max_{s \in S}\text{sim}(d,s)$; $\lambda=0.80$; lexical similarity for diversity term.
- **Stage 5**: Chunk stitching; consecutive chunk merging (same source/page/chunk_index+1); `CHAT_CONTEXT_CHAR_BUDGET=9000` enforcement.

#### 4.4 Generation
- Prompt structure: system (7 anti-injection rules) + scope + context + history + question.
- Ollama streaming: `httpx.AsyncClient`, NDJSON, SSE forwarding.
- History management: DB-loaded turns, `CHAT_HISTORY_CHAR_BUDGET=3000` truncation.

### Section 5 — Experimental Setup

- **Hardware**: CPU-based inference; Ollama on network-accessible server; Qdrant on commodity server.
- **Software versions**: (list from `requirements.txt` after pinning).
- **Dataset**: 201 question/reference pairs, Italian language, domain: ENEA RECON energy community simulator.
- **Metrics**: RAGAS faithfulness, answer_relevancy, context_precision, context_recall, answer_correctness.
- **Evaluation pipeline**: `eval_batch.py` → CSV → `eval_ragas.py` → metric CSV.
- **Judge model**: `gemma4:26b` (generation); `all-MiniLM-L6-v2` (embedding judge for answer_relevancy); caveats on self-evaluation bias.

### Section 6 — Results

- **Table 1**: RAG pipeline ablation — 7 feature flag configurations; context_precision and faithfulness as primary metrics.
- **Table 2**: Chunking comparison — 5 CHUNK_SIZE values; F1(precision, recall) as primary.
- **Table 3**: Retrieval k comparison — 5 (CHAT_CANDIDATES, CHAT_RESULT_LIMIT) pairs; latency-quality Pareto.
- **Table 4**: MMR lambda sweep — 7 lambda values; precision-recall-diversity three-way tradeoff.
- **Table 5**: Reranking strategy — no rerank, hybrid variants, cross-encoder; latency delta quantified.
- **Key findings**: [To be filled after experiments.]

### Section 7 — Discussion

- **Limitations**:
  - No version pins in `requirements.txt`; reproducibility risk.
  - RAGAS judge model is same as generation model → faithfulness bias.
  - No evaluation on standard English benchmarks (NarrativeQA, BEIR); cross-domain generalisability unknown.
  - Single-threaded Qdrant instance; no horizontal scaling.
  - Sentence-boundary heuristic relies on punctuation; degrades on tabular/Excel data.
- **Design trade-offs**:
  - Collection-per-tenant vs. filter-based multi-tenancy: strong isolation at cost of collection overhead.
  - Lexical MMR diversity vs. embedding cosine: faster but may miss semantic duplicates.
  - Monolithic `app.py` vs. microservices: lower operational complexity, harder to scale independently.
- **When to use Mosaico**: Suitable for SMEs, public-sector organisations, researchers needing on-premises RAG with minimal infrastructure. Not suitable as-is for high-concurrency production deployments.

### Section 8 — Conclusion

- Summary of contributions: 5-stage retrieval pipeline, sentence-aware chunker, lexical MMR, stitching, fully local deployment.
- Main empirical finding: [from experiments].
- Practical implication: Mosaico demonstrates that competitive RAG quality is achievable without cloud dependencies using open-weight models and open-source vector search.

### Section 9 — Future Work

- **OCR support**: Add Tesseract/EasyOCR for scanned PDF and image documents (currently pdfplumber handles only text-layer PDFs).
- **Multilingual embeddings**: Replace `all-MiniLM-L6-v2` with a multilingual model (e.g., `paraphrase-multilingual-mpnet-base-v2`) for non-Italian queries.
- **Domain-adapted embedding**: Fine-tune the bi-encoder on the evaluation dataset using hard-negative mining.
- **BM25 hybrid index**: Add a BM25 pre-retrieval stage for exact-term matching in technical documents.
- **Horizontal scaling**: Replace single Qdrant instance with Qdrant distributed mode; introduce connection pooling for the FastAPI workers.
- **Pinned dependencies**: Generate `requirements.lock` for fully reproducible builds.
- **RAGAS with GPT judge**: Run secondary evaluation with a larger, unbiased judge model for validation.
- **GUI evaluation dashboard**: Expose RAGAS metrics in the Django frontend for real-time quality monitoring.

---

## 4. Suggested Figures

### Figure 1 — System Architecture Diagram
Mermaid-style flowchart: Browser → Django → FastAPI → {Qdrant, Ollama, PostgreSQL}. Annotate with port numbers, JWT auth path, and Docker service names. Reference: `docker-compose.yml`.

### Figure 2 — RAG Pipeline Flowchart
Step-by-step swimlane diagram: Raw document → extract → normalise → chunk → embed → Qdrant upsert (ingestion lane). Query → embed → Qdrant search → threshold filter → rerank → MMR → dedup → stitch → prompt → Ollama → SSE stream (query lane). Annotate each step with the relevant function name from `app.py` and the governing env var.

### Figure 3 — Reranking Score Distribution
Box plot or violin plot: distribution of raw vector scores, SequenceMatcher scores, keyword overlap scores, and combined hybrid scores across the 201-question dataset. Illustrates contribution and range of each component. Generated from `eval_batch.py` output with custom logging.

### Figure 4 — MMR Diversity Illustration
Scatter plot of retrieved chunks in 2D PCA/t-SNE projection (from embedding vectors). Show: (a) top-7 chunks by vector score only (potentially clustered), (b) top-7 chunks after MMR with λ=0.80 (more spread). Illustrates the diversity effect visually.

### Figure 5 — Evaluation Metrics Comparison Chart
Radar/spider chart with 5 axes (RAGAS metrics) showing each ablation configuration from Table 1. Visual comparison of trade-offs between full system, no-MMR, no-rerank, and minimal configurations.

### Figure 6 (optional) — Latency Breakdown
Stacked bar chart: per-request latency split into embedding, Qdrant search, reranking, Ollama generation. Shows relative cost of each stage at different `CHAT_CANDIDATES` values.
