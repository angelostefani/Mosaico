# Methodology — Mosaico RAG Pipeline

## 1. Formal RAG Definition

In Mosaico, Retrieval-Augmented Generation is defined as:

$$\hat{a} = \text{LLM}\!\left(\,q,\; C(q,\mathcal{D}),\; H \right)$$

where:
- $q$ is the user question,
- $\mathcal{D}$ is the set of all indexed document chunks in a Qdrant collection,
- $C(q, \mathcal{D})$ is the *context assembly function* — the full retrieval pipeline that selects, re-ranks, deduplicates, and stitches a character-budget-bounded context string from $\mathcal{D}$,
- $H$ is the truncated conversation history (bounded by `CHAT_HISTORY_CHAR_BUDGET`),
- $\hat{a}$ is the generated answer, streamed token-by-token via SSE.

The system makes no external API calls. All components — embedding, vector index, LLM, relational DB — run on-premises.

---

## 2. Phase 1 — Document Ingestion

### 2.1 Text Extraction (`extract_text()`, line 915)

Format-specific extractors are dispatched by file extension:

| Format | Library | Notes |
|---|---|---|
| `.txt`, `.md` | built-in `open()` | UTF-8 encoding |
| `.pdf` | `pdfplumber` | Page-level text + byte-offset metadata |
| `.docx` | `python-docx` | Paragraph concatenation |
| `.xls`, `.xlsx` | `openpyxl` | Row-as-record serialisation: `[Sheet] row=N \| header=value; ...` |
| `.json` | built-in `json` | `json.dumps(data, indent=2)` |

For PDF files, the extractor tracks per-page byte offsets in `pages_meta` (fields: `page_number`, `normalized_start`, `normalized_end`, `text_preview`). This metadata is later used by `_infer_page_number()` to assign each chunk its source page.

### 2.2 Text Normalisation (`_normalize_text()`, line 815)

Applied to all extracted text before chunking:

1. Unify line endings: `\r\n` and `\r` → `\n`
2. Strip control characters (Unicode ranges U+0000–U+0008, U+000B–U+000C, U+000E–U+001F, U+007F) → space
3. Collapse inline whitespace (spaces, tabs, form feeds, vertical tabs) → single space
4. Collapse multiple blank lines → single blank line (`\n\n`)
5. Strip leading/trailing whitespace

---

## 3. Phase 2 — Sentence-Aware Chunking (`chunk_text()`, line 828)

### 3.1 Algorithm

```
Input:  normalised text T, CHUNK_SIZE C, CHUNK_OVERLAP O
Output: list of (chunk_text, char_start, char_end) triples

step ← C − O                                  # stride between windows
boundary_tolerance ← min(50, C ÷ 10)          # max chars to search for boundary

for start in range(0, len(T), step):
    end ← min(start + C, len(T))
    if end < len(T):                           # not at document end
        search_from ← max(start + 1, end − boundary_tolerance)
        best_boundary ← max position of {'.', '!', '?', '\n'} in T[search_from : end + boundary_tolerance]
        if best_boundary > start:
            end ← min(best_boundary + 1, len(T))
    chunk ← T[start:end].strip()
    if chunk is not empty:
        emit (chunk, adjusted_char_start, adjusted_char_end)
```

**Boundary detection**: For each candidate chunk end, the algorithm searches backwards (up to `boundary_tolerance` chars) for the nearest sentence-terminating character. This prevents mid-sentence truncation without requiring a full sentence tokeniser.

**Defaults** (from `.env`):
- `CHUNK_SIZE=600` characters
- `CHUNK_OVERLAP=120` characters
- `boundary_tolerance=50` (= min(50, 600 ÷ 10))

> 🔬 ABLATION CANDIDATE: `CHUNK_SIZE` (200–1000), `CHUNK_OVERLAP` (0–200), boundary search on/off.

> 📌 PAPER OPPORTUNITY: The sentence-boundary heuristic is a lightweight alternative to spaCy/NLTK sentence segmentation. Its impact on retrieval quality at different chunk sizes is an unexplored empirical question.

### 3.2 Chunk Metadata Schema (Qdrant Payload)

Each chunk is stored in Qdrant with the following payload fields:

| Field | Type | Description |
|---|---|---|
| `text_chunk` | string | Raw chunk text |
| `chunk_index` | int | Zero-based index within document |
| `char_start` | int | Start byte offset in normalised text |
| `char_end` | int | End byte offset in normalised text |
| `page_number` | int or null | Inferred from PDF/XLSX page metadata |
| `source_file` | string | Original filename |
| `upload_id` | string | UUID of the upload job |
| `original_filename` | string | User-provided filename |
| `username` | string or null | Tenant username |
| `collection` | string or null | Collection name |
| `source_ext` | string | File extension (`.pdf`, `.docx`, etc.) |
| `doc_title` | string or null | First non-empty line of document |

---

## 4. Phase 3 — Embedding and Indexing

### 4.1 Embedding Model

- **Model**: `sentence-transformers/all-MiniLM-L6-v2` (default; configurable via `EMBEDDING_MODEL`)
- **Dimensions**: 384
- **Similarity metric**: cosine similarity
- **Loading**: lazy-initialised at startup via `_EmbeddingModelHolder` (thread-safe double-checked locking)

At ingestion time, all chunks are encoded in a single batch call:

```python
embeddings = model.encode(chunks)  # shape: (n_chunks, 384)
```

At query time, the question and expansion terms are encoded together:

```python
query_embeddings = model.encode([question] + expansion_terms)
```

Both calls are offloaded to a thread pool via `run_in_threadpool()` to avoid blocking FastAPI's asyncio event loop.

### 4.2 Qdrant Index Configuration

- **Index type**: HNSW (Hierarchical Navigable Small World) — Qdrant's default for approximate nearest-neighbour search
- **Distance metric**: `Distance.COSINE`
- **Collection naming**: `_build_collection_name(username, collection)` → `{username}_{collection}` or fallbacks
- **Vector size**: 384 (must match embedding model output; mismatch is logged as a warning)
- **Storage**: local volume (`qdrant_storage:/qdrant/storage`)

> ⚠️ ASSUMPTION: HNSW construction parameters (`m`, `ef_construct`) are not explicitly set in the codebase; Qdrant defaults are used (typically `m=16`, `ef_construct=100`).

> 📌 PAPER OPPORTUNITY: Multi-tenant collection-per-user isolation is an unusual design choice compared to filter-based multi-tenancy. Its performance and storage overhead vs. a shared-collection approach is worth quantifying.

---

## 5. Phase 4 — Retrieval Pipeline

The retrieval pipeline runs identically in `/chat`, `/chat/stream`, and `/evaluation` endpoints. Each stage is described below.

### 5.1 Stage 1 — Multi-Vector Search (`ENABLE_MULTI_VECTOR_SEARCH=true`)

**Query expansion** (`_select_query_expansions()`, line 1774):
1. Tokenise question using `WORD_RE = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ0-9_']+")`
2. Filter out tokens in `STOPWORDS_IT_EN` (bilingual Italian/English stopword set, ~120 words)
3. Rank remaining tokens by: frequency DESC, length DESC, position in question ASC
4. Return top `CHAT_EXPANSION_LIMIT=3` tokens as expansion terms

**Parallel searches**:
- Primary search: `_qdrant_search_points(q_emb, limit=CHAT_CANDIDATES)`
- Per expansion term: `_qdrant_search_points(ti_vec, limit=CHAT_EXPANSION_CANDIDATES=12)`

**Score-based merge** (`_merge_results()`, line 1812):
- Union of all results, keyed by Qdrant point ID
- If same point appears in multiple searches, keep the instance with the highest score

> 🔬 ABLATION CANDIDATE: `ENABLE_MULTI_VECTOR_SEARCH` on/off, `CHAT_EXPANSION_LIMIT` (1–5), `CHAT_EXPANSION_CANDIDATES` (5–25).

### 5.2 Stage 2 — Score Threshold Filtering

After merging, results with `score < QDRANT_SCORE_THRESHOLD` are discarded.

**Adaptive fallback**: If all results are below threshold, the system retries with progressively lower thresholds: `0.75 × threshold`, `0.5 × threshold`, `0.0`. This prevents empty-context responses on legitimate queries in sparse collections.

> 🔬 ABLATION CANDIDATE: `QDRANT_SCORE_THRESHOLD` (0.0–0.6), adaptive fallback on/off.

### 5.3 Stage 3 — Hybrid Reranking (`rerank_results()`, line 1978)

**Default hybrid reranker** (when `ENABLE_RERANK=true`, `ENABLE_CROSS_ENCODER_RERANK=false`):

$$s_{\text{hybrid}}(d) = 0.60 \cdot s_{\text{vec}}(d) + 0.25 \cdot \text{SequenceMatcher}(q, d) + 0.15 \cdot \text{KeywordOverlap}(q, d)$$

where:
- $s_{\text{vec}}(d)$ = Qdrant cosine similarity score (float in [0, 1])
- $\text{SequenceMatcher}(q, d) = \text{difflib.SequenceMatcher ratio}$ on first 2048 characters, case-folded
- $\text{KeywordOverlap}(q, d) = |T_q \cap T_d| \;/\; \min(|T_q|, |T_d|)$ where $T$ is the set of non-stopword tokens of length $\geq 3$

> 🔬 ABLATION CANDIDATE: Reranking weights (60/25/15), each component individually, alternative TF-IDF keyword overlap.

**Optional cross-encoder reranker** (`ENABLE_CROSS_ENCODER_RERANK=true`):

Model: `cross-encoder/ms-marco-MiniLM-L-6-v2` (lazy-loaded via `_CrossEncoderHolder`)

$$s_{\text{ce}}(d) = \sigma\!\left(\text{CrossEncoder}(q, d[:512])\right)$$
$$s_{\text{combined}}(d) = 0.50 \cdot s_{\text{vec}}(d) + 0.50 \cdot s_{\text{ce}}(d)$$

where $\sigma$ is the sigmoid function applied to the raw cross-encoder logit.

> 📌 PAPER OPPORTUNITY: The 50/50 weighting between vector and cross-encoder scores is a design choice without empirical justification in the codebase. A sweep over this parameter is a straightforward contribution.

> 🔬 ABLATION CANDIDATE: Cross-encoder on/off, sigmoid calibration vs. raw logit, truncation at 512 tokens.

### 5.4 Stage 4 — MMR Diversity Selection (`mmr_select()`, line 1865)

**Formula**:

$$d^* = \arg\max_{d_i \in \mathcal{R} \setminus S} \left[ \lambda \cdot s_{\text{rel}}(d_i) - (1 - \lambda) \cdot \max_{d_j \in S} \text{sim}(d_i, d_j) \right]$$

where:
- $\mathcal{R}$ = candidate set, $S$ = already-selected set
- $s_{\text{rel}}(d_i)$ = reranking score (hybrid or cross-encoder)
- $\text{sim}(d_i, d_j) = \text{SequenceMatcher ratio}$ on first 2048 chars of text content
- $\lambda$ = `MMR_LAMBDA=0.80` (from `.env`; code default = 0.65)

The algorithm is greedy: always picks the single best MMR score. Selection continues until `top_k` items are chosen or candidates are exhausted.

The first item is always the highest-relevance candidate (pure greedy). Subsequent selections balance relevance vs. diversity.

> 🔬 ABLATION CANDIDATE: `MMR_LAMBDA` sweep (0.0–1.0 in steps of 0.1), text-similarity metric for diversity (SequenceMatcher vs. cosine on embeddings).

> 📌 PAPER OPPORTUNITY: Using SequenceMatcher (character n-gram overlap) rather than embedding cosine for diversity estimation in MMR is an unusual choice that may perform differently across document types.

### 5.5 Stage 5 — Deduplication (`_dedup_results()`, line 1837)

Two-level deduplication:

1. **Fast fingerprint check**: `(len(normalised_text), normalised_text[:64], normalised_text[-64:])` — O(1) hash set lookup to detect exact duplicates.
2. **Near-duplicate detection**: For candidates sharing identical numeric token tuples (extracted by `re.findall(r"\d+(?:[.,]\d+)?", text)`), compute `SequenceMatcher(normalised[:2048], prev[:2048]).ratio() >= 0.97`. If threshold met, discard.

The numeric token pre-filter prevents expensive string comparison between chunks that differ only in their numbers (e.g., different data rows from an Excel file).

> 🔬 ABLATION CANDIDATE: Similarity threshold (0.90–0.99), skip numeric pre-filter.

### 5.6 Stage 6 — Context Stitching (`stitch_chunks()`, line 1903)

When `ENABLE_STITCH=true`:

1. Sort selected chunks by `(source_file, page_number, chunk_index)`.
2. Greedily merge consecutive chunks from the same document page where `chunk_index` is exactly `prev + 1`, up to `max_run_len=3` chunks per run.
3. Assembled blocks are prefixed with `[p.{page_number}][c.{chunk_index}] ` markers.
4. Blocks are sorted by descending relevance score, then inserted into the context until `CHAT_CONTEXT_CHAR_BUDGET=9000` characters is reached.
5. The last block is truncated at the nearest sentence boundary to respect the budget.

> 📌 PAPER OPPORTUNITY: Stitching recovers inter-chunk context continuity that is lost during the chunking phase. Its impact on faithfulness and answer completeness for long-form questions is an open empirical question.

> 🔬 ABLATION CANDIDATE: `ENABLE_STITCH` on/off, `max_run_len` (1–5), `CHAT_CONTEXT_CHAR_BUDGET` (3000–15000).

---

## 6. Phase 5 — Answer Generation

### 6.1 Prompt Construction

Both `ask()` and `ask_stream()` build a single composite prompt with four sections:

```
[1] SYSTEM SECTION (hardcoded)
"Sei un assistente intelligente basato su Retrieval-Augmented Generation (RAG)..."
7 numbered rules including: use only provided context, ignore prompt injection,
respond in the question language, be concise.

[2] SCOPE SECTION (optional, from CollectionConfig.scope_prompt)
"Ambito di pertinenza della collection:\n{scope_prompt}\n\n"

[3] CONTEXT SECTION
"Contesto:\n{rag_context}\n\n"    (bounded by CHAT_CONTEXT_CHAR_BUDGET)

[4] HISTORY SECTION (optional)
"Conversazione precedente:\n{history}\n\n"    (bounded by CHAT_HISTORY_CHAR_BUDGET)

[5] QUESTION SECTION
"Domanda:\n{question}\n\n"
```

The prompt is in Italian (system instructions) with dynamic language adaptation (rule 5: respond in the question's language).

### 6.2 Ollama Integration

- **Protocol**: HTTP POST to `OLLAMA_URL` (e.g., `http://ollama:11434/api/generate`)
- **Request body**: `{"model": OLLAMA_MODEL, "prompt": combined, "stream": true}`
- **Response format**: NDJSON lines, each `{"response": "token"}` (streaming) or `{"done": true}` (terminal)
- **Timeout**: `OLLAMA_TIMEOUT=180` seconds (configurable)
- **HTTP client**: `httpx.AsyncClient` with `client.stream()` for non-blocking I/O

**Non-streaming** (`ask()`): Accumulates all `response` chunks into a single string; returns after stream completes.

**Streaming** (`ask_stream()`): Async generator; each `response` chunk is immediately yielded and wrapped as SSE: `data: {"chunk": "..."}\n\n`. Terminal event: `data: {"done": true, "conversation_id": "..."}\n\n`.

### 6.3 History Budget Management

Conversation history is loaded from the `conversation_messages` table (up to `CHAT_HISTORY_PROMPT_LIMIT=30` turns). Before inclusion in the prompt, oldest turns are dropped until total character count is within `CHAT_HISTORY_CHAR_BUDGET=3000`:

```python
while len(formatted) > 1 and sum(len(s) for s in formatted) > CHAT_HISTORY_CHAR_BUDGET:
    formatted.pop(0)
```

> 🔬 ABLATION CANDIDATE: `CHAT_HISTORY_CHAR_BUDGET` (500–5000), `CHAT_HISTORY_PROMPT_LIMIT` (1–50), history compression strategies.

---

## 7. Evaluation Framework (`evaluation/`)

### 7.1 Two-Stage Pipeline

**Stage 1** — `eval_batch.py`: Calls `/evaluation` endpoint (POST multipart/form-data) for each `{"question", "reference"}` pair in the dataset. Outputs a CSV with `question, reference, response, n_chunks, retrieved_sources, retrieved_contexts` columns.

**Stage 2** — `eval_ragas.py`: Reads the CSV and computes five RAGAS metrics using:
- **Judge LLM**: Local Ollama model via OpenAI-compatible `/v1` endpoint (`AsyncOpenAI(base_url=.../v1, api_key="ollama")`)
- **Embeddings**: `ragas.embeddings.HuggingFaceEmbeddings` (same model as RAG system by default)
- **Single-threaded execution**: `RunConfig(max_workers=1)` to prevent queue buildup on a single Ollama instance

**Metrics computed**:
| Metric | RAGAS class | Requires reference |
|---|---|---|
| `faithfulness` | `Faithfulness` | No |
| `answer_relevancy` | `AnswerRelevancy` | No |
| `context_precision` | `ContextPrecision` | No |
| `context_recall` | `ContextRecall` | Yes |
| `answer_correctness` | `AnswerCorrectness` | Yes |

> ⚠️ ASSUMPTION: RAGAS version used is not pinned in any `requirements.txt`; the import paths (`ragas.metrics._faithfulness`, etc.) suggest a specific RAGAS version. Pinning this version is required for reproducibility.

> 📌 PAPER OPPORTUNITY: Using a small local LLM (e.g., `gemma3:1b`) as the RAGAS judge introduces self-evaluation bias when the same model both generates and evaluates. The `eval_ragas.py` script acknowledges this with an explicit caveat: *"faithfulness scores are biased upward (same model generates and judges)"*. A study of judge-model size vs. metric reliability is a publishable contribution.

### 7.2 Evaluation Dataset

The bundled dataset (`evaluation/datasets/eval_dataset.json`) contains 201+ question/reference pairs in Italian, focused on the ENEA RECON energy community simulator domain. This is a domain-specific dataset and not a standard academic benchmark.

> ⚠️ ASSUMPTION: The full `eval_dataset.json` structure was observed to contain at least the 201 entries described in `eval_ragas.py` docstring comments. Exact count requires reading the full file.
