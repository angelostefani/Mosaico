# Experimental Setup — Mosaico RAG Platform

## 1. Hardware Configuration

The Mosaico stack is designed to run on commodity hardware without mandatory GPU support. The production `.env` points to an external Ollama server at `http://192.168.118.218:11434`, indicating the LLM inference is offloaded to a network-accessible host.

| Component | Minimum | Notes |
|---|---|---|
| CPU | 4+ cores | Embedding inference runs on CPU by default |
| RAM | 16 GB | 8 GB for Qdrant + OS; 4–8 GB for LLM depending on model |
| Disk | 20+ GB | Model cache (`hf_model_cache` volume) + document storage |
| GPU (optional) | NVIDIA with CUDA | Ollama uses GPU if available via `--gpus all` in compose |
| Network | LAN | Required if Ollama runs on a separate host |

> ⚠️ ASSUMPTION: GPU configuration for the Ollama container would require adding `deploy.resources.reservations.devices` to the `ollama` service in `docker-compose.yml`. This is not present in the current configuration.

**Ollama GPU enablement** (not currently in `docker-compose.yml`; would require):
```yaml
ollama:
  deploy:
    resources:
      reservations:
        devices:
          - driver: nvidia
            count: 1
            capabilities: [gpu]
```

---

## 2. Software Stack

### 2.1 AI API (`ai_api/requirements.txt`)

| Package | Version pin | Role |
|---|---|---|
| `fastapi` | unpinned | REST API framework |
| `uvicorn` | unpinned | ASGI server (2 workers in Docker) |
| `python-multipart` | unpinned | Multipart form parsing (file upload) |
| `pdfplumber` | unpinned | PDF text extraction |
| `python-docx` | unpinned | DOCX text extraction |
| `openpyxl` | unpinned | XLS/XLSX extraction |
| `sentence-transformers` | unpinned | Bi-encoder embedding (`all-MiniLM-L6-v2`) |
| `qdrant-client` | unpinned | Qdrant vector DB client (REST transport) |
| `requests` | unpinned | Synchronous HTTP (health checks, Ollama tag listing) |
| `python-dotenv` | unpinned | `.env` loading |
| `httpx[http2]` | unpinned | Async HTTP client (Ollama streaming, JWT verify) |
| `SQLAlchemy>=2.0` | `>=2.0` | ORM for uploads/conversations |
| `psycopg[binary]` | unpinned | PostgreSQL driver |
| `pytest` | unpinned | Test suite |

> ⚠️ ASSUMPTION: No version pins are specified in `requirements.txt`. For reproducibility, a `pip freeze` snapshot or a `pyproject.toml` with locked versions is recommended before paper submission.

### 2.2 Django Frontend (`mosaico/requirements.txt`)

| Package | Version pin | Role |
|---|---|---|
| `django` | unpinned | Web framework (version 5.2.3 referenced in settings comment) |
| `djangorestframework` | unpinned | DRF for JWT endpoint |
| `djangorestframework-simplejwt` | unpinned | JWT auth (60-minute token lifetime) |
| `django-cors-headers` | unpinned | CORS middleware |
| `whitenoise` | unpinned | Static file serving |
| `gunicorn` | unpinned | WSGI production server |
| `psycopg[binary]` | unpinned | PostgreSQL driver |
| `python-dotenv` | unpinned | `.env` loading |
| `requests` | unpinned | HTTP calls to FastAPI |

### 2.3 Docker Stack (`docker-compose.yml`)

| Service | Image | Version | Port |
|---|---|---|---|
| `postgres` | `postgres` | `16` | 5432 |
| `qdrant` | `qdrant/qdrant` | `latest` | 6333 |
| `ollama` | `ollama/ollama` | `latest` | 11434 |
| `api` (FastAPI) | local build `./ai_api` | — | 9000 |
| `frontend` (Django) | local build `./mosaico` | — | 9001 |

**API container runtime**: `uvicorn app:app --host 0.0.0.0 --port 9000 --workers 2`

> ⚠️ ASSUMPTION: `qdrant/qdrant:latest` and `ollama/ollama:latest` are unpinned. The exact versions used in experiments should be recorded via `docker inspect <container> | grep RepoDigests` for reproducibility.

### 2.4 Evaluation Dependencies (`evaluation/`)

The evaluation scripts require additional packages not in the main `requirements.txt`:

| Package | Role |
|---|---|
| `ragas` | RAGAS framework (faithfulness, answer_relevancy, etc.) |
| `openai` | AsyncOpenAI client used to interface Ollama via `/v1` API |

Install with: `pip install ragas openai`

---

## 3. Dataset

### 3.1 Bundled Dataset

The repository includes a domain-specific evaluation dataset at `evaluation/datasets/eval_dataset.json`:
- **Language**: Italian
- **Domain**: ENEA RECON simulator and Italian Renewable Energy Communities (CER)
- **Structure**: JSON array of `{"question": "...", "reference": "..."}` objects
- **Size**: 201+ question/reference pairs (per `eval_ragas.py` docstring)
- A mini subset is available at `evaluation/datasets/eval_dataset_mini.json`

### 3.2 Recommended Standard Benchmarks

No general-purpose benchmark dataset is bundled. For comparative evaluation against published RAG systems, the following standard benchmarks are recommended:

| Dataset | Language | Domain | Suitable for |
|---|---|---|---|
| NarrativeQA | English | Literature/fiction | Long-form reading comprehension |
| QuALITY | English | Multi-domain | Long-context QA |
| BEIR (MSMARCO subset) | English | Multi-domain | Retrieval quality |
| TriviaQA | English | General knowledge | Open-domain QA |
| HotpotQA | English | Wikipedia multi-hop | Multi-hop reasoning |

> ⚠️ ASSUMPTION: The current codebase has no scripts for ingesting or evaluating on these standard benchmarks. Adapting the evaluation pipeline would require: (1) converting benchmark format to `eval_dataset.json` schema, (2) ingesting reference documents into Qdrant, (3) running `eval_batch.py` + `eval_ragas.py`.

---

## 4. Hyperparameter Configuration

The following table lists all tunable hyperparameters with their default values as read from `app.py` code defaults, and the actual values configured in the `.env` file:

| Parameter | Env Var | Code Default | `.env` Value | Description |
|---|---|---|---|---|
| Chunk size | `CHUNK_SIZE` | 500 | 600 | Max characters per chunk |
| Chunk overlap | `CHUNK_OVERLAP` | 50 | 120 | Overlap between consecutive chunks |
| Score threshold | `QDRANT_SCORE_THRESHOLD` | 0.3 | 0.45 | Minimum cosine similarity to include result |
| Result limit | `CHAT_RESULT_LIMIT` | 30 | 7 | Max chunks in final context |
| Candidates | `CHAT_CANDIDATES` | 30 | 80 | Chunks retrieved from Qdrant before reranking |
| Context budget | `CHAT_CONTEXT_CHAR_BUDGET` | 7000 | 9000 | Max chars in assembled context |
| History budget | `CHAT_HISTORY_CHAR_BUDGET` | 3000 | 3000 | Max chars of conversation history in prompt |
| History turns | `CHAT_HISTORY_PROMPT_LIMIT` | 30 | 30 | Max turns loaded from DB |
| MMR lambda | `MMR_LAMBDA` | 0.65 | 0.80 | Relevance/diversity tradeoff (1=pure relevance) |
| Expansion limit | `CHAT_EXPANSION_LIMIT` | 3 | 3 | Number of query expansion terms |
| Expansion candidates | `CHAT_EXPANSION_CANDIDATES` | 12 | 12 | Qdrant hits per expansion term |
| Ollama timeout | `OLLAMA_TIMEOUT` | 60 | 180 | Seconds before HTTP timeout |
| Upload size limit | `MAX_UPLOAD_SIZE_BYTES` | 20,000,000 | — | Max file size (bytes) |

> ⚠️ ASSUMPTION: The code defaults (column "Code Default") are the values read directly from `os.getenv('PARAM', default)` calls in `app.py` lines 75–94. The `.env` values represent the configuration used in the authors' own deployment.

> 🔬 ABLATION CANDIDATE: All parameters in this table are suitable for systematic ablation. Priority targets: `CHUNK_SIZE`, `CHAT_CANDIDATES`, `QDRANT_SCORE_THRESHOLD`, `MMR_LAMBDA`, `CHAT_RESULT_LIMIT`.

---

## 5. Feature Flags

| Flag | Env Var | Default (code) | `.env` Value | Description |
|---|---|---|---|---|
| Hybrid reranking | `ENABLE_RERANK` | `true` | `true` | 60/25/15 vector+fuzzy+keyword scoring |
| MMR diversity | `ENABLE_MMR` | `true` | — | Maximal Marginal Relevance selection |
| Chunk stitching | `ENABLE_STITCH` | `true` | — | Merge consecutive chunk runs |
| Multi-vector search | `ENABLE_MULTI_VECTOR_SEARCH` | `true` | — | Query expansion + parallel searches |
| Cross-encoder rerank | `ENABLE_CROSS_ENCODER_RERANK` | `false` | `false` | `ms-marco-MiniLM-L-6-v2` cross-encoder |
| RAG debug logging | `ENABLE_RAG_DEBUG` | `false` | `true` | Debug-level retrieval logs |
| Embedding fallback | `ALLOW_EMBEDDING_FALLBACK` | `false` | `true` | Hash-based fallback when model unavailable |

> 🔬 ABLATION CANDIDATE: All `ENABLE_*` flags form a $2^5 = 32$-combination ablation space (excluding debug/fallback flags).

---

## 6. Evaluation Framework Summary

### 6.1 `/evaluation` Endpoint

FastAPI exposes `POST /evaluation` (`app.py` line 2327) that runs the full RAG pipeline identically to `/chat` but returns structured JSON:

```json
{
  "question": "...",
  "retrieved_contexts": ["chunk1", "chunk2", ...],
  "retrieved_sources": ["file.pdf", ...],
  "response": "...",
  "reference": "..."
}
```

This enables external evaluation tools to access both retrieved evidence and generated answers.

### 6.2 `eval_batch.py` Workflow

```bash
cd evaluation
python eval_batch.py \
  --url http://localhost:9000 \
  --dataset datasets/eval_dataset.json \
  --collection my_collection \
  --output results_20240101.csv
```

### 6.3 `eval_ragas.py` Workflow

```bash
python eval_ragas.py \
  --input results_20240101.csv \
  --metrics faithfulness,answer_relevancy,context_precision,context_recall,answer_correctness \
  --batch-size 10 \
  --verbose
```

**Known limitations** (documented in `eval_ragas.py`):
- 15–30% NaN rate with 1B-parameter judge models
- Faithfulness scores biased upward (same model generates and judges)
- RAGAS prompts are in English; Italian corpus may reduce context_recall quality
- Use scores for *relative* comparison between configurations, not as absolute quality indicators

### 6.4 Metrics Definitions

| Metric | Definition |
|---|---|
| **Faithfulness** | Fraction of answer claims that are supported by the retrieved context (LLM-judge) |
| **Answer Relevancy** | Semantic similarity between generated answer and original question (embedding-based) |
| **Context Precision** | Fraction of retrieved chunks that are relevant to the question (LLM-judge) |
| **Context Recall** | Fraction of reference answer content covered by retrieved contexts (LLM-judge) |
| **Answer Correctness** | Weighted combination of semantic similarity + factual overlap with reference |
