# Related Work Hooks — Mosaico RAG Platform

## 1. Retrieval-Augmented Generation — Fundamentals

**Concept**: Grounding LLM responses in external knowledge retrieved at inference time.

**Semantic Scholar query**: `"retrieval augmented generation" language model knowledge`

**Canonical citations**:
- Lewis, P., Perez, E., Piktus, A., Petroni, F., Karpukhin, V., Goyal, N., ... & Kiela, D. (2020). **Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks**. *NeurIPS 2020*. arXiv:2005.11401
- Guu, K., Lee, K., Tung, Z., Pasupat, P., & Chang, M. W. (2020). **REALM: Retrieval-Augmented Language Model Pre-Training**. *ICML 2020*. arXiv:2002.08909
- Mallen, A., Asai, A., Zhong, V., Das, R., Hajishirzi, H., & Weld, D. (2023). **When Not to Trust Language Models: Investigating Effectiveness of Parametric and Non-Parametric Memories**. *ACL 2023*. arXiv:2212.10511

**Mosaico connection**: Mosaico implements the inference-time retrieval pattern from Lewis et al. The collection-per-tenant isolation and configurable `scope_prompt` extend the base RAG paradigm to multi-tenant, domain-scoped deployments.

---

## 2. Dense Passage Retrieval

**Concept**: Encoding queries and documents into a shared embedding space; retrieval via approximate nearest-neighbour search.

**Semantic Scholar query**: `dense passage retrieval open domain question answering`

**Canonical citations**:
- Karpukhin, V., Oguz, B., Min, S., Lewis, P., Wu, L., Edunov, S., ... & Yih, W. T. (2020). **Dense Passage Retrieval for Open-Domain Question Answering**. *EMNLP 2020*. arXiv:2004.04906
- Xiong, L., Xiong, C., Li, Y., Tang, K. F., Liu, J., Bennett, P. N., ... & Overwijk, A. (2021). **Approximate Nearest Neighbor Negative Contrastive Estimation for Dense Text Retrieval**. *ICLR 2021*. arXiv:2007.00808
- Izacard, G., Caron, M., Hosseini, L., Riedel, S., Bojanowski, P., Joulin, A., & Grave, E. (2022). **Unsupervised Dense Information Retrieval with Contrastive Learning**. *TMLR*. arXiv:2112.09118

**Mosaico connection**: Mosaico uses `all-MiniLM-L6-v2` as a bi-encoder for dense retrieval. Unlike DPR which uses separate query/document encoders fine-tuned on QA data, Mosaico uses a general-purpose sentence embedding model not fine-tuned for the target domain.

> 📌 PAPER OPPORTUNITY: Domain-specific fine-tuning of the bi-encoder on Italian energy/technical documents would be a direct extension and potential improvement.

---

## 3. Sentence Transformers and Bi-Encoders

**Concept**: Fine-tuning BERT-like models with siamese/triplet objectives to produce semantically meaningful sentence embeddings.

**Semantic Scholar query**: `sentence transformers semantic textual similarity bi-encoder`

**Canonical citations**:
- Reimers, N., & Gurevych, I. (2019). **Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks**. *EMNLP 2019*. arXiv:1908.10084
- Reimers, N., & Gurevych, I. (2020). **Making Monolingual Sentence Embeddings Multilingual using Knowledge Distillation**. *EMNLP 2020*. arXiv:2004.09813
- Wang, W., Wei, F., Dong, L., Bao, H., Yang, N., & Zhou, M. (2020). **MiniLM: Deep Self-Attention Distillation for Task-Agnostic Compression of Pre-Trained Transformers**. *NeurIPS 2020*. arXiv:2002.10957

**Mosaico connection**: `all-MiniLM-L6-v2` is a 6-layer MiniLM distilled from a larger model, producing 384-dimensional vectors. It achieves a good quality/speed tradeoff for CPU deployment.

---

## 4. Cross-Encoder Reranking

**Concept**: Using a more expensive cross-attention model to jointly encode query and passage for precise relevance scoring.

**Semantic Scholar query**: `cross-encoder reranking passage retrieval BERT`

**Canonical citations**:
- Nogueira, R., & Cho, K. (2019). **Passage Re-ranking with BERT**. arXiv:1901.04085
- Nogueira, R., Yang, W., Lin, J., & Cho, K. (2019). **Multi-Stage Document Ranking with BERT**. arXiv:1910.14424
- Zhuang, S., & Zuccon, G. (2023). **Open-source Large Language Models are Strong Zero-Shot Query Likelihood Models for Document Ranking**. *EMNLP 2023 Findings*. arXiv:2310.13243

**Mosaico connection**: `ENABLE_CROSS_ENCODER_RERANK=true` loads `cross-encoder/ms-marco-MiniLM-L-6-v2` and combines its sigmoid-normalised score 50/50 with the Qdrant cosine score. This implements a two-stage retrieval architecture analogous to Nogueira et al.'s cascade approach.

---

## 5. Maximal Marginal Relevance

**Concept**: Greedy algorithm to select a diverse subset of documents by maximising relevance while penalising redundancy.

**Semantic Scholar query**: `maximal marginal relevance diversity retrieval MMR`

**Canonical citations**:
- Carbonell, J., & Goldstein, J. (1998). **The Use of MMR, Diversity-Based Reranking for Reordering Documents and Producing Summaries**. *SIGIR 1998*. ACM DL.
- Nardini, F. M., Perego, R., Renso, C., & Venturini, R. (2022). **Efficient and Effective Retrieval of Dense-Sparse Hybrid Vectors using Graph-based Approximate Nearest Neighbour Search**. *SIGIR 2022*.

**Mosaico connection**: `mmr_select()` implements the original Carbonell & Goldstein (1998) greedy MMR with $\lambda = 0.80$ (from `.env`). The novelty is using `SequenceMatcher` character n-gram similarity rather than embedding cosine for the diversity term, enabling MMR without a second embedding lookup.

> 📌 PAPER OPPORTUNITY: Using lexical similarity (SequenceMatcher) vs. semantic similarity (embedding cosine) for the MMR diversity term is an unexplored design choice. Lexical similarity is faster but may over-select documents that differ in wording but share meaning.

---

## 6. Hybrid Retrieval (Dense + Sparse)

**Concept**: Combining vector similarity with lexical overlap (BM25, TF-IDF) for improved retrieval.

**Semantic Scholar query**: `hybrid retrieval dense sparse BM25 fusion`

**Canonical citations**:
- Chen, X., Zhao, W. X., Wang, J., & Wen, J. R. (2021). **Salient Phrase Aware Dense Retrieval: Can a Dense Retriever Imitate a Sparse One?** arXiv:2110.06918
- Ma, X., Wang, L., Yang, N., Wei, F., & Lin, J. (2022). **Hybrid List-Wise Learning to Rank**. *EMNLP 2022*. arXiv:2205.09658
- Lin, J., & Ma, X. (2021). **A Few Brief Notes on DeepImpact, COIL, and a Conceptual Framework for Information Retrieval Techniques**. arXiv:2106.14807

**Mosaico connection**: The hybrid reranker in `rerank_results()` implements a simplified version of dense-sparse fusion without BM25: it combines Qdrant cosine score (dense) with SequenceMatcher ratio (fuzzy string) and keyword overlap (sparse lexical). Unlike standard hybrid retrieval, there is no BM25 index; the sparse signal is computed on-the-fly from retrieved candidates only.

> 📌 PAPER OPPORTUNITY: Adding a BM25 pre-retrieval stage alongside the Qdrant dense search would be a natural extension, particularly for exact-match queries on technical terminology.

---

## 7. Chunking Strategies for RAG

**Concept**: How documents are segmented into indexable units significantly impacts retrieval quality.

**Semantic Scholar query**: `text chunking segmentation retrieval augmented generation document`

**Canonical citations**:
- Sarthi, P., Abdullah, R., Tuli, A., Khanna, S., Goldie, A., & Manning, C. D. (2024). **RAPTOR: Recursive Abstractive Processing for Tree-Organized Retrieval**. *ICLR 2024*. arXiv:2401.18059
- Edge, D., Trinh, H., Cheng, N., Bradley, J., Chao, A., Mody, A., ... & Larson, J. (2024). **From Local to Global: A Graph RAG Approach to Query-Focused Summarization**. arXiv:2404.16130
- Shi, W., Min, S., Yasunaga, M., Seo, M., James, R., Lewis, M., ... & Hajishirzi, H. (2023). **REPLUG: Retrieval-Augmented Black-Box Language Models**. arXiv:2301.12652

**Mosaico connection**: Mosaico uses a sentence-boundary-aware sliding window chunker, which is a lightweight middle ground between fixed-size chunking (fast, context-unaware) and semantic chunking (slow, requires sentence tokeniser). The boundary heuristic (search for `.!?\n` within ±50 chars) is a pragmatic design choice.

---

## 8. Streaming LLM Inference

**Concept**: Returning generated tokens incrementally to reduce perceived latency.

**Semantic Scholar query**: `streaming inference large language model server-sent events latency`

**Canonical citations**:
- Kwon, W., Li, Z., Zhuang, S., Sheng, Y., Zheng, L., Yu, C. H., ... & Stoica, I. (2023). **Efficient Memory Management for Large Language Model Serving with PagedAttention**. *SOSP 2023*. arXiv:2309.06180
- Yu, G. X., Jeong, J., Kim, G. Y., Kim, S., & Chun, B. G. (2022). **Orca: A Distributed Serving System for Transformer-Based Generative Models**. *OSDI 2022*.

**Mosaico connection**: Mosaico uses Ollama's streaming NDJSON protocol over HTTP with `httpx.AsyncClient`. Each response token is immediately forwarded as a Server-Sent Event (`data: {"chunk": "..."}\n\n`). This is a direct HTTP streaming approach, simpler than production-grade serving systems like vLLM but sufficient for a local deployment.

---

## 9. Multi-Tenant Vector Stores

**Concept**: Serving multiple isolated users or namespaces from a shared vector database.

**Semantic Scholar query**: `multi-tenant vector database isolation retrieval`

**References**:
- Qdrant documentation: "Multitenancy" — https://qdrant.tech/documentation/guides/multiple-partitions/
- Johnson, J., Douze, M., & Jégou, H. (2019). **Billion-Scale Similarity Search with GPUs**. *IEEE T-BD*. arXiv:1702.08734 (FAISS — foundational work for similarity search at scale)

**Mosaico connection**: Mosaico uses one Qdrant collection per `(username, collection)` pair rather than Qdrant's recommended filter-based multi-tenancy (payload filter on `username`). The collection-per-tenant approach provides stronger isolation and avoids accidental cross-tenant leakage but at the cost of storage overhead and collection management complexity.

> 📌 PAPER OPPORTUNITY: A quantitative comparison of collection-per-tenant vs. filter-based multi-tenancy in terms of query latency, storage overhead, and isolation guarantees in Qdrant is a publishable systems contribution.

---

## 10. Local LLM Deployment

**Concept**: Running large language models on commodity hardware without cloud API dependencies.

**Semantic Scholar query**: `local LLM inference quantization edge deployment privacy`

**Canonical citations**:
- Touvron, H., et al. (2023). **Llama 2: Open Foundation and Fine-Tuned Chat Models**. arXiv:2307.09288
- Frantar, E., Ashkboos, S., Hoefler, T., & Alistarh, D. (2022). **GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers**. arXiv:2210.17323

**Relevant tools**:
- **Ollama** (https://ollama.com): Provides a unified REST API for running quantised local models. Default model in `.env`: `gemma4:26b`. The `ollama-pull` container in `docker-compose.yml` auto-downloads the model.
- **llama.cpp**: The inference engine underlying many local deployment tools.

**Mosaico connection**: Privacy and offline operation are first-class design goals. `OLLAMA_URL` supports both local Docker (`http://ollama:11434`) and remote server configurations. No data leaves the deployment boundary.

---

## 11. RAG Evaluation

**Concept**: Frameworks for measuring retrieval and generation quality in RAG systems.

**Semantic Scholar query**: `RAG evaluation framework faithfulness context recall RAGAS`

**Canonical citations**:
- Es, S., James, J., Espinosa-Anke, L., & Schockaert, S. (2023). **RAGAS: Automated Evaluation of Retrieval Augmented Generation**. arXiv:2309.15217
- Chen, J., Lin, H., Han, X., & Sun, L. (2024). **Benchmarking Large Language Models in Retrieval-Augmented Generation**. *AAAI 2024*. arXiv:2309.01431
- Saad-Falcon, J., Khattab, O., Potts, C., & Zaharia, M. (2024). **ARES: An Automated Evaluation Framework for Retrieval-Augmented Generation Systems**. *NAACL 2024*. arXiv:2311.09476

**Mosaico connection**: `eval_ragas.py` uses the RAGAS framework (Es et al., 2023) with local Ollama as judge LLM and HuggingFace embeddings. The script explicitly documents the limitation of using the same generation model as judge.

---

## 12. Novelty Assessment

### 12.1 What Mosaico Does That Differs from Standard RAG

| Aspect | Standard RAG | Mosaico |
|---|---|---|
| Multi-tenancy | Single shared index | Collection-per-tenant isolation |
| Chunking | Fixed-size | Sentence-boundary-aware sliding window |
| Reranking signal | Dense only or BM25+dense | Cosine + SequenceMatcher + keyword overlap (no BM25) |
| MMR diversity metric | Embedding cosine | SequenceMatcher character similarity |
| Context assembly | Concatenate top-k | Sort → dedup → stitch consecutive chunks |
| Anti-injection | Rare | 7-rule hardcoded system prompt |
| Deployment | Cloud-dependent | Fully local, no cloud dependency |
| Evaluation | Standard benchmarks | RAGAS + domain-specific Italian dataset |

### 12.2 Primary Novel Contributions

1. **Lightweight sentence-boundary chunker**: No dependency on NLTK/spaCy; uses punctuation search within configurable tolerance.
2. **Lexical-similarity MMR**: Substitutes embedding cosine with SequenceMatcher for diversity, enabling MMR without a second model call.
3. **Adaptive score threshold fallback**: Progressive threshold relaxation prevents empty-context failures without manual tuning.
4. **Chunk stitching**: Post-retrieval context assembly restoring cross-chunk continuity without hierarchical indexing.
5. **Fully local, multi-tenant RAG**: Complete stack (embed, index, retrieve, generate) running on-premises with per-tenant collection isolation.

---

## 13. Target Venues

| Venue | Type | Fit | Notes |
|---|---|---|---|
| EMNLP | Conference (A*) | High | RAG methodology, evaluation |
| ACL | Conference (A*) | High | Information retrieval + NLP |
| ECIR | Conference (A) | High | Information retrieval systems |
| SIGIR | Conference (A*) | High | Retrieval systems, evaluation |
| COLING | Conference (A) | Medium | Multilingual, applied NLP |
| Applied Sciences (MDPI) | Open access journal | High | Systems paper, practical deployment |
| Information Processing & Management (Elsevier) | Journal (Q1) | High | Document management + IR |
| Knowledge-Based Systems (Elsevier) | Journal (Q1) | Medium | AI systems |
